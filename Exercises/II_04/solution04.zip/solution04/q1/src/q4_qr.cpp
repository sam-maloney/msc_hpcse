#include "q4_qr.hpp"

void q4_qr_validation(const double * const X,
                      const double * const y,
                      double * const beta,
                      const int n,
                      const int p)
{

    double *X_copy, *y_copy;
    posix_memalign((void **) &X_copy, _ALIGN, n*p*sizeof(double));
    posix_memalign((void **) &y_copy, _ALIGN, n*sizeof(double));

    std::memcpy((void *) X_copy, X, n*p*sizeof(double));
    std::memcpy((void *) y_copy, y, n*sizeof(double));

    LAPACKE_dgels(LAPACK_ROW_MAJOR,  // int matrix_layout
                  'N',               // char trans                 
                  n,                 // lapack_int m
                  p,                 // lapack_int n
                  1,                 // lapack_int nrhs
                  X_copy,            // double* a
                  p,                 // lapack_int lda
                  y_copy,            // double* b
                  1);                // lapack_int ldb

    std::memcpy((void *) beta, y_copy, p*sizeof(double));

    free(X_copy);
    free(y_copy);
}

void q4_qr_routine(const double * const X,
                   const double * const y,
                   double * const beta,
                   const int n,
                   const int p)
{
    double (* X_copy)[p], *tau, *scratch;
    posix_memalign((void **) &X_copy, _ALIGN, n*p*sizeof(double));
    posix_memalign((void **) &tau, _ALIGN, p*sizeof(double));
    posix_memalign((void **) &scratch, _ALIGN, n*sizeof(double));

    std::memcpy((void *) X_copy, X, n * p * sizeof(double));
    std::memcpy((void *) scratch, y, n * sizeof(double));

    LAPACKE_dgeqrf(LAPACK_ROW_MAJOR,  // int matrix_layout
                   n,                 // lapack_int m
                   p,                 // lapack_int n
                   (double *) X_copy, // double* a
                   p,                 // lapack_int lda  
                   tau);              // double* tau

    LAPACKE_dormqr(LAPACK_ROW_MAJOR,  // int matrix_layout,
                   'L',               // char side
                   'T',               // char trans
                   n,                 // lapack_int m
                   1,                 // lapack_int n
                   p,                 // lapack_int k
                   (double *) X_copy, // const double* a
                   p,                 // lapack_int lda
                   tau,               // const double* tau
                   scratch,           // double* c
                   1);                // lapack_int lcd

    LAPACKE_dtrtrs(LAPACK_ROW_MAJOR,  // int matrix_layout
                   'U',               // char uplo
                   'N',               // char trans
                   'N',               // char diag
                   p,                 // lapack_int n
                   1,                 // lapack_int nrhs
                   (double *) X_copy, // const double * a
                   p,                 // lapack_int lda  
                   scratch,           // double * b
                   1);                // lapack_int ldb

    std::memcpy((void *) beta, scratch, p * sizeof(double));

    free(X_copy);
    free(tau);
    free(scratch);
}

void q4_qr_initialize_data(double ** _X,
                           double ** _y,
                           double ** _true_beta,
                           double ** _our_beta,
                           double ** _val_beta,
                           const int n,
                           const int p)
{
    posix_memalign((void **) _X, _ALIGN, n*p*sizeof(double));
    posix_memalign((void **) _y, _ALIGN, n*sizeof(double));
    posix_memalign((void **) _true_beta, _ALIGN, p*sizeof(double));
    posix_memalign((void **) _our_beta, _ALIGN, p*sizeof(double));
    posix_memalign((void **) _val_beta, _ALIGN, p*sizeof(double));

    memset(*_our_beta, 0, p * sizeof(double));
    memset(*_val_beta, 0, p * sizeof(double));

    double (* X)[p] = (double (*)[p]) (*_X);
    double (* y) = (double *) (*_y);
    double (* true_beta) = (double *) (*_true_beta);

    std::default_random_engine gen(std::time(NULL));
    std::normal_distribution<double> dist(0., 1.);

    for(int j = 0; j < p; ++j)
        true_beta[j] = 5.0 * dist(gen) + 3.0;

    for(int i = 0; i < n; ++i){
        double dot_prod = 0.;
        for(int j = 0; j < p; ++j){
            X[i][j] = dist(gen);
            dot_prod += X[i][j] * true_beta[j] + dist(gen);
        }
        y[i] = dot_prod;
    }

}

void q4_qr_destroy_data(double * const X,
                        double * const y,
                        double * const true_beta,
                        double * const our_beta,
                        double * const val_beta)
{
    free(X);
    free(y);
    free(true_beta);
    free(our_beta);
    free(val_beta);
}

void q4_qr(){
    // Up to Nx = 2^expsize
    const int expsize = 20;
    const int p = 30;

    // Error behaviour:
    {   
        omp_set_num_threads(1);
        omp_set_dynamic(0);

        printf("error profile\n");
        printf("%10s %10s %10s %10s %10s %10s\n",
               "n", "val. err.", "est. err.", "|valb|", "|ourb|", "|trueb|");

        for(long n = 1 << 5, i = 0; n <= (1 << expsize);
            i += 1, n <<= 1)
        {
            double *X, *y, *true_beta, *our_beta, *val_beta;
            q4_qr_initialize_data(&X, &y, &true_beta, &our_beta, &val_beta, n, p);
            q4_qr_routine(X, y, our_beta, n, p);
            q4_qr_validation(X, y, val_beta, n, p);

            const double val_err = l2_norm(val_beta, our_beta, p),
                         est_err = l2_norm(our_beta, true_beta, p),
                         val_beta_norm = l2_norm(val_beta, NULL, p),
                         our_beta_norm = l2_norm(our_beta, NULL, p),
                         true_beta_norm = l2_norm(true_beta, NULL, p);

            printf("%10ld %10.7lf %10.7lf %10.7lf %10.7lf %10.7lf\n",
                   n, val_err, est_err, val_beta_norm, our_beta_norm,
                   true_beta_norm);
            q4_qr_destroy_data(X, y, true_beta, our_beta, val_beta);
        }
    }

    // Serial profile
    {   
        omp_set_num_threads(1);
        omp_set_dynamic(0);
        double first_time = 0.;
        const int n_runs = 30;

        printf("error profile\n");
        printf("%10s %10s %10s\n", "n", "rel. time", "abs. time");
        for(long n = 1 << 5, i = 0; n <= (1 << expsize);
            i += 1, n <<= 1)
        {
            double avg_time = 0.;
            double *X, *y, *true_beta, *our_beta, *val_beta;
            q4_qr_initialize_data(&X, &y, &true_beta, &our_beta,
                                  &val_beta, n, p);
            for(int k = 0; k < n_runs; ++k){
                const double t1 = omp_get_wtime();            
                q4_qr_routine(X, y, our_beta, n, p);
                const double t2 = omp_get_wtime();
                avg_time += (t2 - t1);
                cache_scrambler();
            }
    
            avg_time /= n_runs;
            first_time = (i == 0) ? avg_time : first_time;

            printf("%10ld %10.3lf %10.7lf\n",
                   n, avg_time / first_time, avg_time);
            q4_qr_destroy_data(X, y, true_beta, our_beta, val_beta);
        }
    }

    // Parallelization
    {   
        double first_time = 0.;
        const int n_runs = 30;
        const long n = 1 << expsize;

        printf("error profile\n");
        printf("%10s %10s %10s %10s\n",
               "n", "# threads", "speedup", "abs. time");
        for(int nthread = 1; nthread <= _NTHREADS; ++nthread)
        {
            omp_set_num_threads(nthread);
            omp_set_dynamic(0);

            double avg_time = 0.;
            double *X, *y, *true_beta, *our_beta, *val_beta;
            q4_qr_initialize_data(&X, &y, &true_beta, &our_beta,
                                  &val_beta, n, p);
            for(int k = 0; k < n_runs; ++k){
                const double t1 = omp_get_wtime();            
                q4_qr_routine(X, y, our_beta, n, p);
                const double t2 = omp_get_wtime();
                avg_time += (t2 - t1);
                cache_scrambler();
            }
    
            avg_time /= n_runs;
            first_time = (nthread == 1) ? avg_time : first_time;

            printf("%10ld %10d %10.3lf %10.7lf\n",
                   n, nthread, first_time / avg_time, avg_time);
            q4_qr_destroy_data(X, y, true_beta, our_beta, val_beta);
        }
    }    

}