/*
 *  Author: Jernej Fink
 *  Date:   12/03/2017
 */

#ifndef Q4_QR_H
#define Q4_QR_H

#include <cmath>
#include <mkl.h>
#include <cstring>
#include <cstdlib>
#include <omp.h>
#include <random>
#include <ctime>
#include "util.hpp"

#define _ALIGN 4096

/*
 *  q4_qr_routine - routine to calculate beta using qr for question 3a).
 *
 *  Args:
 *      - X     pointer to the data set X in row major format
 *      - y     pointer to the data set y in row major format
 *      - beta  pointer to where the beta vector will be saved
 *      - n     number of data points (rows X == rows y == p)
 *      - p     dimensionality of X (cols X == cols beta == p)
 *
 *  Preconditions:
 *      - X points to allocated memory region of size
 *        (n * p * sizeof(double))
 *      - y points to allocated memory region of size
 *        (n * sizeof(double))
 *      - beta points to allocated memory region of size
 *        (p * sizeof(double))
 *      - memory regions pointed to by X, y and beta do not overlap.
 *      - n > p
 *      - X should be a matrix of rank p.
 *
 *  Postconditions:
 *      - memory region at beta includes the least squares coefficient
 *        of linear regression Y = X * beta
 *
 *  Raises:
 *      
 */
void q4_qr_routine(const double * const X,
                   const double * const y,
                   double * const beta,
                   const int n,
                   const int p);

void q4_qr_validation(const double * const X,
                      const double * const y,
                      double * const beta,
                      const int n,
                      const int p);

void q4_qr_initialize_data(double ** _X,
                           double ** _y,
                           double ** _true_beta,
                           double ** _our_beta,
                           double ** _val_beta,
                           const int n,
                           const int p);

void q4_qr_destroy_data(double * const X,
                        double * const y,
                        double * const true_beta,
                        double * const our_beta,
                        double * const val_beta);

void q4_qr();

#endif