/*
 *  Author: Jernej Fink
 *  Date:   12/03/2017
 */

#ifndef UTIL_H
#define UTIL_H

#include <stdlib.h> 
#include <cmath>

inline void cache_scrambler()
{
    srand(time(NULL));
    float * pointers[10];
    for(int i = 0; i < 10; ++i) 
    {
        pointers[i] = (float *) calloc(10000, sizeof(float));
    }
    for(int j = 0; j < 10000; ++j) {
        for(int i = 0; i < 10; ++i) 
        {
            pointers[i][j] = (float) rand() / (float) RAND_MAX;
            pointers[i][j] *= pointers[i][j];
        }
    }
    for(int i = 0; i < 10; ++i) {
        free(pointers[i]);
    }
}

inline double l_inf_norm(const double * const x,
                         const double * const y,
                         const int n)
{
    double norm = 0.;
    for(int i = 0; i < n; ++i){
        const double curr = (y == NULL) ? std::fabs(x[i]) : 
                                          std::fabs(x[i] - y[i]);
        norm = curr > norm ? curr : norm;
    }
    return norm;
}

inline double l2_norm(const double * const x,
                      const double * const y,
                      const int n)
{
    double norm = 0.;
    for(int i = 0; i < n; ++i){
        const double curr = (y == NULL) ? x[i] * x[i] : 
                                          (x[i] - y[i]) * (x[i] - y[i]);
        norm += curr;
    }
    return std::sqrt(norm);
}

#endif