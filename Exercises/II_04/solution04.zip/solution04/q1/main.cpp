#include <iostream>
#include <string>
#include <exception>
#include <ctime>
#include <stdexcept>

#include "q4_qr.hpp"

int main(int argc, char *argv[]){
    if(argc != 2)
        throw std::invalid_argument("Wrong number of parameters. "
                                    "The syntax is: main [qr]\n");

    const std::string input(argv[1]);

    if(input == std::string("qr"))
        q4_qr();
        
    else
        throw std::invalid_argument("Wrong parameter " + input + ". "
                                    "Should be one of [qr]\n");

    return 0;
}
