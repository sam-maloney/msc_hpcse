Before running the Makefile, run the following
command:

$ source setup.sh [Darwin, Euler]

Use Darwin for OSX machines and Euler for 
the Euler cluster. You may modify the setup.sh
such that you can run it locally, but you
have to set the correct values for the
library paths.