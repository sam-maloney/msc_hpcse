import matplotlib.pyplot as plt
import numpy as np

all_types = ['default', 'default_sock', 'balance', 'balance_sock', 'bynode', 'bynode_sock']
all_N     = [10, 11, 12, 14]

markers = ['D', 'H', 'x', 'd', '<', 'h', '+', '*', 'o', 'p',  's',  'v', '^', '>']
colors = ['r', 'b', 'g', 'm']
lstyle = ['-', '--']


for t in all_types:
    plt.figure()
    for i, N in enumerate(all_N):
        data = np.loadtxt('time.%s.N%s.dat' % (t,N))
        plt.plot(data[:,1], data[0,2] / data[:,2], '-%s%s'%(colors[i], markers[i]), label='N=%s' % N)
    plt.title('Type %s' % t)
    plt.xlabel('number of processes')
    plt.ylabel('Speedup')
    plt.xlim(xmin=1)
    xmin,xmax = plt.xlim()
    x = np.linspace(xmin, xmax)
    plt.plot(x,x,'-k')
    plt.legend(loc='best')
    plt.savefig('fig_%s.pdf' % t)


for N in all_N:
    plt.figure()
    for i, t in enumerate(all_types):
        data = np.loadtxt('time.%s.N%s.dat' % (t,N))
        plt.plot(data[:,1], data[0,2] / data[:,2], '%s%s%s'%(lstyle[i%2], colors[i/2], markers[i]), label='%s' % t)
    plt.title('N=%s' % N)
    plt.xlabel('number of processes')
    plt.ylabel('Speedup')
    plt.xlim(xmin=1)
    xmin,xmax = plt.xlim()
    x = np.linspace(xmin, xmax)
    plt.plot(x,x,'-k')
    plt.legend(loc='best')
    plt.savefig('fig_N%s.pdf' % N)

plt.show()