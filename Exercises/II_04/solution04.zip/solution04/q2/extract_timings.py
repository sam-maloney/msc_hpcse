import numpy as np
import re
import sys

if len(sys.argv) < 2:
    print 'Usage:', sys.argv[0], 'fname [fname [...]]'
files = sys.argv[1:]

timpattern = re.compile('performance:[^\d]*(\d+)[^\d]*(\S+)[^\d]*(\d+)')
# performance:    2       0.098   1024

data = []
for f in files:
    for l in open(f).readlines(): 
        match = timpattern.match(l)
        if match: 
            data.append([float(match.group(3)), float(match.group(1)), float(match.group(2))])

data = np.array(data)
order = np.argsort(data[:,1])
data = data[order]

print '#', 'N', 'numprocs', 'time'
np.savetxt(sys.stdout, data)
