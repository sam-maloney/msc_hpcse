#!/bin/bash

N=$1
types=(default balance bynode default_sock balance_sock bynode_sock)

for t in ${types[@]}; do
	bsub -n 48 -W 1:00 -o job_$t.N$N.out.log ./runjob.sh $N $t
done

