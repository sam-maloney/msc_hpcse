#!/bin/bash

types=(default default_sock balance balance_sock bynode bynode_sock)
allN=(10 11 12 14)

for N in ${allN[@]}; do
  for t in ${types[@]}; do
    echo "Extracting N=$N $t"
    python extract_timings.py data/results_$t.N$N*.dat > time.$t.N$N.dat
  done
done
