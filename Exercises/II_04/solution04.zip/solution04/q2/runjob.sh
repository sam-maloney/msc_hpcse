#!/bin/bash

N=$1
type=$2

prog_serial=./diffusion_serial
prog_mpi=diffusion_mpi

ncores=(1 2 4 8 12 16 20 24 28 32 36 40 44 48)

case $type in
    default )
        opt="-bycore -bind-to-core" ;;
    balance )
        opt="-bycore -bind-to-core -loadbalance" ;;
    bynode )
        opt="-bycore -bind-to-core -bynode" ;;
    default_sock )
        opt="-bysocket -bind-to-socket" ;;
    balance_sock )
        opt="-bysocket -bind-to-socket -loadbalance" ;;
    bynode_sock )
        opt="-bysocket -bind-to-socket -bynode" ;;
esac

echo "# N   : $N"
echo "# Opt : $opt"

echo "Running serial"
$prog_serial > results_$type.N$N.serial.dat


for n in ${ncores[@]}; do
	echo "Running mpi np=$n"
	mpirun -np $n -report-bindings $opt $prog_mpi $N > results_$type.N$N.np$n.dat
done

