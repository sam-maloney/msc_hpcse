#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#include <sys/time.h>

#include "q1_mc.h"
#include "q1_integrands.h"

#ifndef M_E
#define M_E 2.7182818285
#endif

static uint32_t lcg(const uint32_t a){
    // source: https://en.wikipedia.org/wiki/Lehmer_random_number_generator
    return ((uint64_t) a * 279470273UL) % 4294967291UL;
}

double q1_mc_integrate(double (*f)(const double), 
                                   const double a, 
                                   const double b,
                                   const int N,
                                   const int nthreads)
{

    double integral = 0., integrals[_NTHREADS];
    const int work = N / nthreads;

    #pragma omp parallel num_threads(nthreads)
    {   
        const int nt = omp_get_thread_num();
        uint32_t curr_a = nt + 3454325;
        double curr_integral = 0.;
        for(int i = 0; i < ((nt == 0) ? work + N % nthreads : work); ++i) 
        {
            curr_a = lcg(curr_a);
            const double x = ((double) curr_a / (double) 4294967291UL); //in [0,1]
            curr_integral += f(a + (b - a) * x);
        }
        integrals[omp_get_thread_num()] = curr_integral;
    }
    for(int i = 0; i < nthreads; ++i)
        integral += integrals[i];

    return (b-a) * integral / N;
}

double q1_bonus_integrand(const double x){
    return (x >= 0 && x < 1) ? -(x - 1)*(x + 1) * exp(-x) : 0.;
}

double q1_mc_integrate_bonus(const int N)
{

    const double a = 0, b = 1.;
    double integral = 0;
    for(int i = 0; i < N; ++i) {
        const uint32_t curr_a = rand();
        const double t  = ((double) curr_a / (double) RAND_MAX); //in [0,1]
        const double x = -log(1 - t);
        const double fval = (x >= 0 && x < 1) ? -(x - 1)*(x + 1) : 0.;
        integral += fval;
    }
    integral *= (b - a);
    integral /= N;
    return integral;
}

typedef double (*analytic_fun_t)();
typedef double (*integrand_fun_t)(const double);
void q1_mc() {

    srand(time(NULL));
    // Up to 2^expsize;
    const int expsize = 20;
    
    // TODO: set the correct lower bounds, each element for one integrand
    const double a[] = {-1, 0.,};

    // TODO: set the correct upper bound, each element for one integrand
    const double b[] = {1., 5.,};

    const integrand_fun_t funs [] = {integrand_1, integrand_2};
    const analytic_fun_t analytic[] = {analytic_solution_1, analytic_solution_2};

    
    // Validation
    {    
        printf("validation error\n");
        for(int nfun = 0; nfun < 2; ++nfun){
            printf("function: %3d\n", nfun);
            printf("%10s %10s\n", "N", "error");
            for(long N = 2, i = 0; N <= (1 << expsize);  i += 1, N <<= 1){
                const double trapz = 
                    q1_mc_integrate(funs[nfun], a[nfun], b[nfun], N, 4);
                const double analy = (*analytic[nfun])();
                const double err = fabs(trapz - analy);
                printf("%10ld %10.7f\n", N, err);
            }
        }
    }

    // Serial execution:
    {   

        printf("\nserial profile\n");
        const long n_repeats = 30, n_runs = 3;
        double first_time = 0.;
        printf("%10s %10s %10s\n", "N", "rel. time", "abs. time");
        for(long N = 2, i = 0; N <= (1 << expsize);  i += 1, N <<= 1){
            // Run n_repeats experiments.
            double avg_time = 0.;
            for(int k = 0; k < n_repeats; ++k) {

                // Timing over three runs, to minimize 
                // the overhead of the clock.
                const double t1 = omp_get_wtime();
                for(int t = 0; t < n_runs; ++t)
                    q1_mc_integrate(integrand_1, a[0], b[0], N, 1);
                const double t2 = omp_get_wtime();

                const double dt = t2 - t1;
                avg_time += dt;
            }
            avg_time /= n_repeats;
            first_time = i == 0 ? avg_time : first_time;
            printf("%10ld %10.4f %10.2f\n", N, avg_time / first_time, avg_time);
        }
    }

    // Parallel strong scaling:
    {

        printf("\nparallel profile: strong scaling\n");
        const long N = 1 << expsize, n_repeats = 30, n_runs = 3;
        double first_time = 0.;

        // Run n_repeats experiments.
        printf("%10s %10s %10s %10s\n", "nthreads", "N", "rel. time", "abs. time");
        for(int nthr = 1; nthr <= _NTHREADS; ++nthr){

            double avg_time = 0.;
            for(int k = 0; k < n_repeats; ++k) {

                // Timing over three runs, to minimize 
                // the overhead of the clock.
                const double t1 = omp_get_wtime();
                for(int t = 0; t < n_runs; ++t)
                    q1_mc_integrate(integrand_1, a[0], b[0], N, nthr);
                const double t2 = omp_get_wtime();

                const double dt = t2 - t1;
                avg_time += dt;
            }
            avg_time /= n_repeats;
            first_time = nthr == 1 ? avg_time : first_time;
            printf("%10d %10ld %10.7f %10.2f\n", nthr, N, first_time / avg_time, avg_time);
        }
    }

    // Bonus question: pick a(x) = -(x-1)*(x+1) on [0, 1]; b(x) = exp(-x);
    // Then Int a(x) b(x) is Exp[a(x)] w.r.t. to measure u(dx) = b(x)dx = exp(-x) dx
    // Instead of uniform sampling, we can sample X ~ exp(-x)
    // and evaluate a(x)
    {
        printf("bonus error\n");
        printf("%10s %10s %10s\n", "N", "bonus err", "mc err");
        for(long N = 2, i = 0; N <= (1 << expsize);  i += 1, N <<= 1){
            const double mc_bonus = q1_mc_integrate_bonus(N);
            const double mc = q1_mc_integrate(q1_bonus_integrand, 0, 1, N, 1);
            const double analy = (4 - M_E) / M_E;
            const double err_bonus = fabs(mc - analy);
            const double err_mc = fabs(mc_bonus - analy);
            printf("%10ld %10.7f %10.7f\n", N, err_bonus, err_mc);
        }
    }


}