#include "q1_diff.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>
#include <omp.h>

int q1_diff_stencil(double * const result,
                    const double a,
                    const double b,
                    const double T,
                    const double D,
                    double (*f0)(const double),
                    const double g_a, 
                    const double g_b,
                    const int Nx,
                    const int Nt,
                    const int nthreads)
{
    // param result:    pointer to the data, 
    //                  allocated memory should be of size 
    //                  Nt * Nx * sizeof(double) bytes
    // param a, b:      boundaries of the diffusion problem,
    // param T:         final time
    // param D:         diffusion coefficient,
    // param f0:        initial value function,
    // param g_a, g_b:  boundary values at boundaries a, b respectively
    // param Nx, Nt:    number of spatial- and temporal-discretization 
    //                  intervals.

    // returns 0 on success, 1 on error.

    double (*r)[Nx + 1]   = (double (*)[Nx + 1]) result;
    double h = (b - a) / Nx, dt = T / Nt;

    for(int i = 0; i <= Nx; ++i)
    	r[0][i] = f0(i * h);

    const double diff_c = D * dt / h / h;
    // Do iterations over time
    #pragma omp parallel num_threads(nthreads)
    for(int k = 1; k <= Nt; ++k) {
        #pragma omp single
        {
            r[k][0] = g_a;
            r[k][Nx] = g_b;
        }

        #pragma omp for
    	for(int i = 1; i < Nx; ++i){
            const double d1 = r[k-1][i+1] - r[k-1][i];
            const double d2 = r[k-1][i] - r[k-1][i-1];
            const double c1 = d1 - d2;
            r[k][i] = r[k-1][i] + c1 * diff_c;
        }
    }

    return 0;
}

double q1_diff_f0(const double x){
    return (x <= 1 && x >= 0) ? -(x - 1) * (x + 1) : 0.;
}


static void cache_scrambler()
{
    srand(time(NULL));
    float * pointers[10];
    for(int i = 0; i < 10; ++i) 
    {
        pointers[i] = (float *) calloc(10000, sizeof(float));
    }
    for(int j = 0; j < 10000; ++j) {
        for(int i = 0; i < 10; ++i) 
        {
            pointers[i][j] = (float) rand() / (float) RAND_MAX;
            pointers[i][j] *= pointers[i][j];
        }
    }
    for(int i = 0; i < 10; ++i) {
        free(pointers[i]);
    }
}

void q1_diff() {

    // Up to Nx = 2^expsize
    const int expsize = 10;

    // Domain bounds, a is lower bound, b is upper
    const double a = 0., b = 1.;

    // Boundary values
    const double g_a = 1., g_b = 0.;

    // Final time
    const double T = 0.1;

    // Diffusion coefficient
    const double D = 0.1;
    
    // Set the number of time intervals required for CFL condition,
    // such that it is valid for all Nx = 1 ... 2^expsize.
    const long maxNx = 1 << expsize;
    const long Nt = (long) (1.1 * (maxNx + 1) * (maxNx + 1) * D * T / (b - a) / (b - a));

    // Serial execution:
    {   

        printf("\nserial profile\n");
        const int n_repeats = 30;
        double first_time = 0.;
        printf("%10s %10s %10s %10s\n", "Nx", "Nt", "rel. time", "CFL");
        for(long Nx = 2, i = 0; Nx <= (1 << expsize);  i += 1, Nx <<= 1){
            // Run n_repeats experiments.
            double avg_time = 0.;
            double * stencil = calloc((Nt + 1) * (Nx + 1), sizeof(double));
            for(int k = 0; k < n_repeats; ++k) {

                const double t1 = omp_get_wtime();
                q1_diff_stencil(stencil, a, b, T, D, q1_diff_f0, g_a,
                                g_b, Nx, Nt, 1);
                const double t2 = omp_get_wtime();
                cache_scrambler();
                const double dt = t2 - t1;
                avg_time += dt;
            }
            free(stencil);
            avg_time /= n_repeats;
            first_time = i == 0 ? avg_time : first_time;
            const double h = (b - a) / Nx, ddt = T / Nt;
            
            printf("%10ld %10ld %10.7f %10.7f\n", Nx, Nt, avg_time / first_time, D * ddt / h / h / 2.);
        }
    }

    // Parallel strong scaling:
    {

        printf("\nparallel profile: strong scaling\n");
        const long Nx = 1 << expsize, n_repeats = 30;
        double first_time = 0.;

        printf("%10s %10s %10s %10s %10s\n", "nthreads", "Nx", "Nt", "speedup", "abs_time");
        // Run n_repeats experiments.
        for(int nthr = 1; nthr <= _NTHREADS; ++nthr){

            double avg_time = 0.;
            double * stencil = calloc((Nt + 1) * (Nx + 1), sizeof(double));
            for(int k = 0; k < n_repeats; ++k) {
                const double t1 = omp_get_wtime();
                q1_diff_stencil(stencil, a, b, T, D, q1_diff_f0, g_a, 
                                g_b, Nx, Nt, nthr);
                const double t2 = omp_get_wtime();
                cache_scrambler();
                const double dt = t2 - t1;
                avg_time += dt;
            }
            free(stencil);
            avg_time /= n_repeats;
            first_time = nthr == 1 ? avg_time : first_time;
            printf("%10d %10ld %10ld %10.7f %10.7f\n", nthr, Nx, Nt, first_time / avg_time, avg_time);
        }
    }
}