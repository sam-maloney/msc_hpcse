#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "q1_trapz.h"
#include "q1_integrands.h"

double q1_trapz_integrate(double (*f)(const double),
                                 const double a, 
                                 const double b,
                                 const int N,
                                 const int nthreads) 
{
    const double h = (b - a) / N;
    double integral = (f(a) + f(b)) / 2.;

    #pragma omp parallel num_threads(nthreads)
    {
        #pragma omp for reduction(+:integral)
        for(int i = 1; i < N; ++i)
            integral += f(a + i*h);
    }

    integral *= h;

    return integral;
}

typedef double (*analytic_fun_t)();
typedef double (*integrand_fun_t)(const double);
void q1_trapz() {

    // Up to 2^expsize;
    const int expsize = 20;

    // TODO: set the correct lower bounds, each element for one integrand
    const double a[] = {-1, 0.,};

    // TODO: set the correct upper bound, each element for one integrand
    const double b[] = {1., 30.,};

    const integrand_fun_t funs [] = {integrand_1, integrand_2};
    const analytic_fun_t analytic[] = {analytic_solution_1, analytic_solution_2};
    
    // Validation
    {    
        printf("validation error\n");
        for(int nfun = 0; nfun < 2; ++nfun){
            printf("function: %3d\n", nfun);
            printf("%10s %10s\n", "N", "error");
            for(long N = 2, i = 0; N <= (1 << expsize);  i += 1, N <<= 1){
                const double trapz = 
                    q1_trapz_integrate(funs[nfun], a[nfun], b[nfun], N, 3);
                const double analy = (*analytic[nfun])();
                const double err = fabs(trapz - analy);
                printf("%10ld %10.7f\n", N, err);
            }
        }
    }

    // Serial execution:
    {   

        printf("\nserial profile\n");
        const int n_repeats = 30,
                  n_runs = 3;
        double first_time = 0.;
        printf("%10s %10s %10s\n", "N", "rel. time", "abs. time");
        for(long N = 2, i = 0; N <= (1 << expsize);  i += 1, N <<= 1){
            // Run n_repeats experiments.
            double avg_time = 0.;
            for(int k = 0; k < n_repeats; ++k) {

                // Timing over three runs, to minimize 
                // the overhead of the clock.
                const double t1 = omp_get_wtime();
                for(int t = 0; t < n_runs; ++t)
                    q1_trapz_integrate(integrand_1, a[0], b[0], N, 1);
                const double t2 = omp_get_wtime();

                const double dt = t2 - t1;
                avg_time += dt;
            }
            avg_time /= n_repeats;
            first_time = i == 0 ? avg_time : first_time;
            printf("%10ld %10.4f %10.2f\n", N, avg_time / first_time, avg_time);
        }
    }

    // Parallel strong scaling:
    {

        printf("\nparallel profile: strong scaling\n");
        const long N = 1 << expsize, n_repeats = 30, n_runs = 3;
        double first_time = 0.;

        printf("%10s %10s %10s %10s\n", "nthreads", "N", "rel. time", "abs. time");
        // Run n_repeats experiments.
        for(int nthr = 1; nthr <= _NTHREADS; ++nthr){

            double avg_time = 0.;
            for(int k = 0; k < n_repeats; ++k) {

                // Timing over three runs, to minimize 
                // the overhead of the clock.
                // gettimeofday(&tv1, NULL);
                const double t1 = omp_get_wtime();
                for(int t = 0; t < n_runs; ++t)
                    q1_trapz_integrate(integrand_1, a[0], b[0], N, nthr);
                // gettimeofday(&tv2, NULL);
                const double t2 = omp_get_wtime();

                const double dt = t2 - t1;
                avg_time += dt;
            }
            avg_time /= n_repeats;
            first_time = nthr == 1 ? avg_time : first_time;
            printf("%10d %10ld %10.7f %10.2f\n", nthr, N, first_time / avg_time, avg_time);
        }
    }
}

