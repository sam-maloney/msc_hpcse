#include <math.h>
#include "q1_integrands.h"

double integrand_1(const double x){
    return -(x-1)*(x+1);
}

double integrand_2(const double x){
    return exp(-x);
}

double analytic_solution_1() {
    return 4./3.;
}

double analytic_solution_2() {
    return 1.;
}