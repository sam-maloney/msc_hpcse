#include "q1_integrands.h"

double integrand_1(const double x) {
    // TODO: Implement the first integrand:
    return 0.;
}

double integrand_2(const double x) {
    // TODO: Implement the second integrand:
    return 0.;
}

double analytic_solution_1() {
    // TODO: Implement the analytic solution for the first integral:
    return 1.;
}

double analytic_solution_2() {
    // TODO: Implement the analytic solution for the first integral:
    return 1.;
}
