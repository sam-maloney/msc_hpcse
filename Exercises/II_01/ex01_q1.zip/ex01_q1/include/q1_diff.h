#ifndef Q1_DIFF_H
#define Q1_DIFF_H

void q1_diff();

#endif 