#!/bin/bash
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --time=00:10:00
#SBATCH --account=s659

export OMP_NUM_THREADS=12
srun  ./diffusion_cuda 11
srun  ./diffusion_openmp 11
