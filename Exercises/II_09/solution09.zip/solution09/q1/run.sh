#!/bin/bash
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
#SBATCH --time=00:10:00
#SBATCH --account=s659
#SBATCH --constraint=gpu

srun  ./diffusion_cuda_shared 11
