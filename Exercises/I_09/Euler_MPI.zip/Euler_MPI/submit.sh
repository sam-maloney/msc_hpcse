bsub -n 48 < script
